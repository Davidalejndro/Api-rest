package proyectoEscalab.Usuarioapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
